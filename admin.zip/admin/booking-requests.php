<?php
require_once '../config/database.php';
requireLogin();

// Allow both admin and staff to access booking requests
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php?error=access_denied");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$messageType = '';

// Handle status update for booking requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'confirm_request' || $_POST['action'] === 'cancel_request') {
        $request_id = $_POST['request_id'] ?? null;
        $new_status = ($_POST['action'] === 'confirm_request') ? 'confirmed' : 'cancelled';

        if ($request_id) {
            $query = "UPDATE booking_requests SET status = ? WHERE id = ?";
            $stmt = $db->prepare($query);
            if ($stmt->execute([$new_status, $request_id])) {
                $message = "Booking request status updated to " . $new_status . ".";
                $messageType = 'success';
            } else {
                $message = "Failed to update booking request status.";
                $messageType = 'error';
            }
        }
    }
}

// Fetch all booking requests
$queryRequests = "SELECT * FROM booking_requests ORDER BY created_at DESC";
$stmtRequests = $db->prepare($queryRequests);
$stmtRequests->execute();
$allRequests = $stmtRequests->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Requests - Dynasty Hotel Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fdf2f8',
                            500: '#ec4899',
                            600: '#db2777',
                            700: '#be185d',
                            900: '#831843'
                        }
                    },
                    animation: {
                        'fade-in
