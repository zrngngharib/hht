<?php
require_once '../config/database.php';
requireLogin();

// Allow both admin and staff to access bookings
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php?error=access_denied");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$messageType = '';

// Handle Add/Edit Booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $room_id = $_POST['room_id'] ?? null;
    $guest_id = $_POST['guest_id'] ?? null;
    $check_in_date = $_POST['check_in_date'] ?? '';
    $check_out_date = $_POST['check_out_date'] ?? '';
    $total_price = $_POST['total_price'] ?? '';
    $status = $_POST['status'] ?? 'pending';

    if (empty($room_id) || empty($guest_id) || empty($check_in_date) || empty($check_out_date) || empty($total_price)) {
        $message = "All fields are required.";
        $messageType = 'error';
    } else {
        // Calculate num_nights based on 24-hour logic (12 PM to 12 PM)
        // For simplicity with DATE fields, we'll count full days.
        // If check-in is 2025-07-17 and check-out is 2025-07-18, it's 1 night.
        $datetime1 = new DateTime($check_in_date . ' 12:00:00');
        $datetime2 = new DateTime($check_out_date . ' 12:00:00');
        $interval = $datetime1->diff($datetime2);
        $num_nights = $interval->days;

        if ($_POST['action'] === 'add') {
            $query = "INSERT INTO bookings (room_id, guest_id, check_in_date, check_out_date, num_nights, total_price, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $db->prepare($query);
            if ($stmt->execute([$room_id, $guest_id, $check_in_date, $check_out_date, $num_nights, $total_price, $status])) {
                $message = "Booking added successfully!";
                $messageType = 'success';
            } else {
                $message = "Failed to add booking.";
                $messageType = 'error';
            }
        } elseif ($_POST['action'] === 'edit') {
            $id = $_POST['id'] ?? null;
            if ($id) {
                $query = "UPDATE bookings SET room_id = ?, guest_id = ?, check_in_date = ?, check_out_date = ?, num_nights = ?, total_price = ?, status = ? WHERE id = ?";
                $stmt = $db->prepare($query);
                if ($stmt->execute([$room_id, $guest_id, $check_in_date, $check_out_date, $num_nights, $total_price, $status, $id])) {
                    $message = "Booking updated successfully!";
                    $messageType = 'success';
                } else {
                    $message = "Failed to update booking.";
                    $messageType = 'error';
                }
            }
        }
    }
}

// Handle Delete Booking
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM bookings WHERE id = ?";
    $stmt = $db->prepare($query);
    if ($stmt->execute([$id])) {
        $message = "Booking deleted successfully!";
        $messageType = 'success';
    } else {
        $message = "Failed to delete booking.";
        $messageType = 'error';
    }
}

// Fetch all bookings
$queryBookings = "SELECT b.*, r.room_number, g.first_name, g.last_name 
                  FROM bookings b 
                  JOIN rooms r ON b.room_id = r.id 
                  JOIN guests g ON b.guest_id = g.id 
                  ORDER BY b.check_in_date DESC";
$stmtBookings = $db->prepare($queryBookings);
$stmtBookings->execute();
$allBookings = $stmtBookings->fetchAll(PDO::FETCH_ASSOC);

// Fetch rooms for dropdown (initially all rooms)
$rooms = [];
$queryRooms = "SELECT id, room_number, price_per_night FROM rooms ORDER BY room_number ASC";
$stmtRooms = $db->prepare($queryRooms);
$stmtRooms->execute();
$rooms = $stmtRooms->fetchAll(PDO::FETCH_ASSOC);

// Fetch guests for dropdown
$guests = [];
$queryGuests = "SELECT id, first_name, last_name FROM guests ORDER BY first_name ASC";
$stmtGuests = $db->prepare($queryGuests);
$stmtGuests->execute();
$guests = $stmtGuests->fetchAll(PDO::FETCH_ASSOC);

$editBooking = null;
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM bookings WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);
    $editBooking = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookings Management - Dynasty Hotel Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fdf2f8',
                            500: '#ec4899',
                            600: '#db2777',
                            700: '#be185d',
                            900: '#831843'
                        }
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-up': 'slideUp 0.6s ease-out',
                        'pulse-slow': 'pulse 3s infinite'
                    }
                }
            }
        }
    </script>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 transition-colors duration-300" x-data="{ darkMode: false, sidebarOpen: true }" x-init="darkMode = localStorage.getItem('darkMode') === 'true'" :class="{ 'dark': darkMode }">

    <!-- Sidebar -->
    <div class="fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out" :class="{ '-translate-x-full': !sidebarOpen }">
        <div class="flex items-center justify-center h-16 bg-primary-600 text-white">
            <i class="fas fa-crown text-2xl mr-2"></i>
            <span class="text-xl font-bold">Dynasty Admin</span>
        </div>
        
        <nav class="mt-8">
            <div class="px-4 space-y-2">
                <a href="dashboard.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
                </a>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="rooms.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-bed mr-3"></i>Rooms
                </a>
                <a href="room-types.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-tags mr-3"></i>Room Types
                </a>
                <?php endif; ?>
                <a href="bookings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors bg-gray-100 dark:bg-gray-700">
                    <i class="fas fa-calendar-check mr-3"></i>Bookings
                </a>
                <a href="booking-requests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-inbox mr-3"></i>Booking Requests
                </a>
                <a href="room-status.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-calendar-alt mr-3"></i>Room Status
                </a>
                <a href="guests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-users-line mr-3"></i>Guests
                </a>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="users.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-users mr-3"></i>Users
                </a>
                <a href="settings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-cog mr-3"></i>Settings
                </a>
                <?php endif; ?>
                <a href="uploaded-documents.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-file-alt mr-3"></i>Uploaded Docs
                </a>
            </div>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="transition-all duration-300 ease-in-out" :class="{ 'ml-64': sidebarOpen, 'ml-0': !sidebarOpen }">
        <!-- Top Navigation -->
        <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
            <div class="flex items-center justify-between px-6 py-4">
                <div class="flex items-center space-x-4">
                    <button @click="sidebarOpen = !sidebarOpen" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Bookings Management</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <button @click="darkMode = !darkMode; localStorage.setItem('darkMode', darkMode)" class="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                        <i class="fas fa-moon" x-show="!darkMode"></i>
                        <i class="fas fa-sun" x-show="darkMode"></i>
                    </button>
                    
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" class="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                            <div class="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-white text-sm"></i>
                            </div>
                            <span class="font-medium"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                            <i class="fas fa-chevron-down text-sm"></i>
                        </button>
                        
                        <div x-show="open" @click.away="open = false" x-transition class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2">
                            <a href="profile.php" class="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                <i class="fas fa-user mr-2"></i>Profile
                            </a>
                            <a href="logout.php" class="block px-4 py-2 text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                <i class="fas fa-sign-out-alt mr-2"></i>Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Bookings Content -->
        <main class="p-6">
            <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-100 dark:bg-green-900 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-300' : 'bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-300'; ?>">
                <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i><?php echo $message; ?>
            </div>
            <?php endif; ?>

            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 mb-6">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4"><?php echo $editBooking ? 'Edit Booking' : 'Add New Booking'; ?></h3>
                <form action="bookings.php" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4" x-data="{ checkInDate: '<?php echo htmlspecialchars($editBooking['check_in_date'] ?? ''); ?>', checkOutDate: '<?php echo htmlspecialchars($editBooking['check_out_date'] ?? ''); ?>', availableRooms: [], selectedRoomPrice: 0, totalPrice: <?php echo htmlspecialchars($editBooking['total_price'] ?? 0); ?> }" x-init="
                    $watch('checkInDate', () => fetchAvailableRooms());
                    $watch('checkOutDate', () => fetchAvailableRooms());
                    function fetchAvailableRooms() {
                        if (checkInDate && checkOutDate && new Date(checkInDate) < new Date(checkOutDate)) {
                            fetch('api/get_available_rooms.php?check_in=' + checkInDate + '&check_out=' + checkOutDate)
                                .then(response => response.json())
                                .then(data => {
                                    availableRooms = data;
                                    // If editing, ensure the current room is in the list even if it's now booked
                                    <?php if ($editBooking): ?>
                                        const currentRoomId = <?php echo $editBooking['room_id']; ?>;
                                        if (!availableRooms.some(room => room.id == currentRoomId)) {
                                            fetch('api/get_room_details.php?id=' + currentRoomId) // You'd need this API
                                                .then(response => response.json())
                                                .then(roomData => {
                                                    if (roomData) {
                                                        availableRooms.unshift(roomData); // Add to the beginning
                                                    }
                                                });
                                        }
                                    <?php endif; ?>
                                });
                        } else {
                            availableRooms = [];
                        }
                    };
                    fetchAvailableRooms(); // Initial fetch on load
                    $watch('selectedRoomPrice', () => {
                        if (checkInDate && checkOutDate && selectedRoomPrice > 0) {
                            const date1 = new Date(checkInDate + 'T12:00:00');
                            const date2 = new Date(checkOutDate + 'T12:00:00');
                            const diffTime = Math.abs(date2 - date1);
                            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                            totalPrice = selectedRoomPrice * diffDays;
                        } else {
                            totalPrice = 0;
                        }
                    });
                ">
                    <input type="hidden" name="action" value="<?php echo $editBooking ? 'edit' : 'add'; ?>">
                    <?php if ($editBooking): ?>
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($editBooking['id']); ?>">
                    <?php endif; ?>
                    <div>
                        <label for="room_id" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Room:</label>
                        <select id="room_id" name="room_id" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500" @change="selectedRoomPrice = $event.target.options[$event.target.selectedIndex].dataset.price">
                            <option value="">-- Select Room --</option>
                            <template x-for="room in availableRooms" :key="room.id">
                                <option :value="room.id" :data-price="room.price_per_night" :selected="room.id == <?php echo htmlspecialchars($editBooking['room_id'] ?? 'null'); ?>">
                                    <span x-text="room.room_number"></span> (<span x-text="room.room_type_name || 'N/A'"></span>) - $<span x-text="room.price_per_night"></span>/night
                                </option>
                            </template>
                            <option x-if="availableRooms.length === 0 && checkInDate && checkOutDate && new Date(checkInDate) < new Date(checkOutDate)" value="" disabled>No rooms available for selected dates.</option>
                            <option x-if="!checkInDate || !checkOutDate || new Date(checkInDate) >= new Date(checkOutDate)" value="" disabled>Select valid check-in/check-out dates to see available rooms.</option>
                        </select>
                    </div>
                    <div>
                        <label for="guest_id" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Guest:</label>
                        <div class="flex items-center space-x-2">
                            <select id="guest_id" name="guest_id" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                                <option value="">-- Select Guest --</option>
                                <?php foreach ($guests as $guest): ?>
                                    <option value="<?php echo htmlspecialchars($guest['id']); ?>" <?php echo ($editBooking && $editBooking['guest_id'] == $guest['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($guest['first_name'] . ' ' . $guest['last_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <a href="guests.php?action=add" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-3 rounded focus:outline-none focus:shadow-outline transition-colors duration-300 text-sm" title="Add New Guest">
                                <i class="fas fa-user-plus"></i>
                            </a>
                        </div>
                    </div>
                    <div>
                        <label for="check_in_date" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Check-in Date:</label>
                        <input type="date" id="check_in_date" name="check_in_date" x-model="checkInDate" value="<?php echo htmlspecialchars($editBooking['check_in_date'] ?? ''); ?>" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                    </div>
                    <div>
                        <label for="check_out_date" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Check-out Date:</label>
                        <input type="date" id="check_out_date" name="check_out_date" x-model="checkOutDate" value="<?php echo htmlspecialchars($editBooking['check_out_date'] ?? ''); ?>" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                    </div>
                    <div>
                        <label for="total_price" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Total Price:</label>
                        <input type="number" step="0.01" id="total_price" name="total_price" x-model="totalPrice" readonly class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500 bg-gray-100 dark:bg-gray-700 cursor-not-allowed">
                    </div>
                    <div>
                        <label for="status" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Status:</label>
                        <select id="status" name="status" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                            <option value="pending" <?php echo ($editBooking && $editBooking['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="confirmed" <?php echo ($editBooking && $editBooking['status'] == 'confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                            <option value="checked-in" <?php echo ($editBooking && $editBooking['status'] == 'checked-in') ? 'selected' : ''; ?>>Checked-in</option>
                            <option value="checked-out" <?php echo ($editBooking && $editBooking['status'] == 'checked-out') ? 'selected' : ''; ?>>Checked-out</option>
                            <option value="cancelled" <?php echo ($editBooking && $editBooking['status'] == 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="md:col-span-2 flex justify-end">
                        <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition-colors duration-300">
                            <?php echo $editBooking ? 'Update Booking' : 'Add Booking'; ?>
                        </button>
                        <?php if ($editBooking): ?>
                            <a href="bookings.php" class="ml-2 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition-colors duration-300">
                                Cancel
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">All Bookings</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white dark:bg-gray-800 rounded-lg overflow-hidden">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Room</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Guest</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Check-in</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Check-out</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Nights</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Total Price</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                            <?php if (empty($allBookings)): ?>
                                <tr>
                                    <td colspan="8" class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400 text-center">No bookings found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach($allBookings as $booking): ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white"><?php echo htmlspecialchars($booking['room_number']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300"><?php echo htmlspecialchars($booking['first_name'] . ' ' . $booking['last_name']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300"><?php echo htmlspecialchars($booking['check_in_date']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300"><?php echo htmlspecialchars($booking['check_out_date']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300"><?php echo htmlspecialchars($booking['num_nights']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">$<?php echo htmlspecialchars(number_format($booking['total_price'], 2)); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                            <?php 
                                                if ($booking['status'] == 'pending') echo 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
                                                else if ($booking['status'] == 'confirmed') echo 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
                                                else if ($booking['status'] == 'checked-in') echo 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
                                                else if ($booking['status'] == 'checked-out') echo 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300';
                                                else if ($booking['status'] == 'cancelled') echo 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
                                            ?>">
                                            <?php echo htmlspecialchars(ucfirst($booking['status'])); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <a href="bookings.php?action=edit&id=<?php echo htmlspecialchars($booking['id']); ?>" class="text-primary-600 hover:text-primary-900 mr-3">Edit</a>
                                        <a href="bookings.php?action=delete&id=<?php echo htmlspecialchars($booking['id']); ?>" onclick="return confirm('Are you sure you want to delete this booking?');" class="text-red-600 hover:text-red-900">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
