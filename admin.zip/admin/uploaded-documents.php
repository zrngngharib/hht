<?php
require_once '../config/database.php';
// Change the requireRole line to allow staff access
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php?error=access_denied");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$messageType = '';

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['document'])) {
$uploadDir = '../uploads/documents/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0775, true);
}

$file = $_FILES['document'];
$guest_id = $_POST['guest_id'] ?? null;

if ($file['error'] === UPLOAD_ERR_OK) {
    // Get guest full name for naming convention
    $guest_full_name = 'unknown_guest';
    if ($guest_id) {
        $queryGuest = "SELECT first_name, last_name FROM guests WHERE id = ?";
        $stmtGuest = $db->prepare($queryGuest);
        $stmtGuest->execute([$guest_id]);
        $guest = $stmtGuest->fetch(PDO::FETCH_ASSOC);
        if ($guest) {
            $guest_full_name = str_replace(' ', '_', $guest['first_name'] . '_' . $guest['last_name']);
        }
    }

    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = $guest_full_name . '_' . date('d_m_Y') . '.' . $fileExtension;
    $destination = $uploadDir . $fileName;

    // Check if file already exists and append a number if it does
    $counter = 1;
    $originalFileName = $fileName;
    while (file_exists($destination)) {
        $fileName = pathinfo($originalFileName, PATHINFO_FILENAME) . '_' . $counter . '.' . $fileExtension;
        $destination = $uploadDir . $fileName;
        $counter++;
    }

    if (move_uploaded_file($file['tmp_name'], $destination)) {
        // Optionally, save the document path to the guest's record in the database
        if ($guest_id) {
            $updateGuestQuery = "UPDATE guests SET id_document = ? WHERE id = ?";
            $updateGuestStmt = $db->prepare($updateGuestQuery);
            $updateGuestStmt->execute([$fileName, $guest_id]);
        }
        $message = "Document uploaded successfully: " . htmlspecialchars($fileName);
        $messageType = 'success';
    } else {
        $message = "Failed to upload document.";
        $messageType = 'error';
    }
} else {
    $message = "Upload error: " . $file['error'];
    $messageType = 'error';
}
}

// Fetch all guests for the upload form dropdown
$queryGuests = "SELECT id, first_name, last_name FROM guests ORDER BY first_name";
$stmtGuests = $db->prepare($queryGuests);
$stmtGuests->execute();
$allGuests = $stmtGuests->fetchAll(PDO::FETCH_ASSOC);

// Fetch all uploaded documents
$uploadedDocuments = [];
$uploadDir = '../uploads/documents/';
if (is_dir($uploadDir)) {
$files = array_diff(scandir($uploadDir), array('.', '..'));
foreach ($files as $file) {
    $filePath = $uploadDir . $file;
    if (is_file($filePath)) {
        $uploadedDocuments[] = [
            'name' => $file,
            'path' => $filePath,
            'encrypted_path' => base64_encode($file) // Encrypt filename for URL
        ];
    }
}
}
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Uploaded Documents - Dynasty Hotel Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script>
    tailwind.config = {
        darkMode: 'class',
        theme: {
            extend: {
                colors: {
                    primary: {
                        50: '#fdf2f8',
                        500: '#ec4899',
                        600: '#db2777',
                        700: '#be185d',
                        900: '#831843'
                    }
                },
                animation: {
                    'fade-in': 'fadeIn 0.5s ease-in-out',
                    'slide-up': 'slideUp 0.6s ease-out',
                    'pulse-slow': 'pulse 3s infinite'
                }
            }
        }
    }
</script>
<style>
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    @keyframes slideUp {
        from { transform: translateY(30px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }
</style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 transition-colors duration-300" x-data="{ darkMode: false, sidebarOpen: true, showLightbox: false, lightboxSrc: '' }" x-init="darkMode = localStorage.getItem('darkMode') === 'true'" :class="{ 'dark': darkMode }">

<!-- Sidebar -->
<div class="fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out" :class="{ '-translate-x-full': !sidebarOpen }">
    <div class="flex items-center justify-center h-16 bg-primary-600 text-white">
        <i class="fas fa-crown text-2xl mr-2"></i>
        <span class="text-xl font-bold">Dynasty Admin</span>
    </div>
    
    <nav class="mt-8">
        <div class="px-4 space-y-2">
            <a href="dashboard.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
            </a>
            <a href="rooms.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-bed mr-3"></i>Rooms
            </a>
            <a href="room-types.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-tags mr-3"></i>Room Types
            </a>
            <a href="bookings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-calendar-check mr-3"></i>Bookings
            </a>
            <a href="room-status.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-calendar-alt mr-3"></i>Room Status
            </a>
            <a href="guests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-users-line mr-3"></i>Guests
            </a>
            <a href="users.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-users mr-3"></i>Users
            </a>
            <a href="settings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-cog mr-3"></i>Settings
            </a>
            <a href="uploaded-documents.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 bg-primary-100 dark:bg-primary-900 rounded-lg">
                <i class="fas fa-file-alt mr-3"></i>Uploaded Docs
            </a>
        </div>
    </nav>
</div>

<!-- Main Content -->
<div class="transition-all duration-300 ease-in-out" :class="{ 'ml-64': sidebarOpen, 'ml-0': !sidebarOpen }">
    <!-- Top Navigation -->
    <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div class="flex items-center justify-between px-6 py-4">
            <div class="flex items-center space-x-4">
                <button @click="sidebarOpen = !sidebarOpen" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Uploaded Documents</h1>
            </div>
            
            <div class="flex items-center space-x-4">
                <button @click="darkMode = !darkMode; localStorage.setItem('darkMode', darkMode)" class="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                    <i class="fas fa-moon" x-show="!darkMode"></i>
                    <i class="fas fa-sun" x-show="darkMode"></i>
                </button>
                
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" class="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                        <div class="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white text-sm"></i>
                        </div>
                        <span class="font-medium"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                        <i class="fas fa-chevron-down text-sm"></i>
                    </button>
                    
                    <div x-show="open" @click.away="open = false" x-transition class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2">
                        <a href="profile.php" class="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                            <i class="fas fa-user mr-2"></i>Profile
                        </a>
                        <a href="logout.php" class="block px-4 py-2 text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </header>

    <!-- Uploaded Documents Content -->
    <main class="p-6">
        <?php if ($message): ?>
        <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-100 dark:bg-green-900 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-300' : 'bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-300'; ?>">
            <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i><?php echo $message; ?>
        </div>
        <?php endif; ?>

        <!-- Upload Form -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 mb-6">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Upload New Document</h3>
            <form method="POST" enctype="multipart/form-data" class="space-y-4">
                <div>
                    <label for="guest_id" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Assign to Guest (Optional)</label>
                    <select id="guest_id" name="guest_id" class="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all duration-300">
                        <option value="">Select Guest</option>
                        <?php foreach($allGuests as $guest): ?>
                        <option value="<?php echo $guest['id']; ?>"><?php echo htmlspecialchars($guest['first_name'] . ' ' . $guest['last_name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="document" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Select Document (Image files only)</label>
                    <input type="file" id="document" name="document" accept="image/*" required
                           class="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all duration-300 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary-50 file:text-primary-700 hover:file:bg-primary-100">
                </div>
                <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
                    <i class="fas fa-upload mr-2"></i>Upload Document
                </button>
            </form>
        </div>

        <!-- Documents List -->
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">All Uploaded Documents</h3>
            <?php if (empty($uploadedDocuments)): ?>
                <p class="text-gray-500 dark:text-gray-400">No documents uploaded yet.</p>
            <?php else: ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                    <?php foreach($uploadedDocuments as $doc): ?>
                    <div class="bg-gray-50 dark:bg-gray-700 rounded-lg shadow-md overflow-hidden">
                        <div class="h-40 bg-gray-200 dark:bg-gray-600 flex items-center justify-center overflow-hidden">
                            <img src="api/view_document.php?path=<?php echo htmlspecialchars($doc['encrypted_path']); ?>" 
                                 alt="<?php echo htmlspecialchars($doc['name']); ?>" 
                                 class="object-cover w-full h-full cursor-pointer transition-transform duration-300 hover:scale-105"
                                 @click="showLightbox = true; lightboxSrc = 'api/view_document.php?path=<?php echo htmlspecialchars($doc['encrypted_path']); ?>'">
                        </div>
                        <div class="p-4">
                            <p class="text-sm font-medium text-gray-900 dark:text-white truncate" title="<?php echo htmlspecialchars($doc['name']); ?>">
                                <?php echo htmlspecialchars($doc['name']); ?>
                            </p>
                            <button @click="showLightbox = true; lightboxSrc = 'api/view_document.php?path=<?php echo htmlspecialchars($doc['encrypted_path']); ?>'"
                                    class="mt-2 text-primary-600 hover:text-primary-700 text-sm transition-colors">
                                <i class="fas fa-eye mr-1"></i>View
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<!-- Lightbox Modal -->
<div x-show="showLightbox" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-80" style="display: none;">
    <div class="relative max-w-4xl max-h-full p-4">
        <button @click="showLightbox = false" class="absolute top-4 right-4 text-white text-3xl hover:text-gray-300 transition-colors">
            <i class="fas fa-times"></i>
        </button>
        <img :src="lightboxSrc" class="max-w-full max-h-[90vh] object-contain rounded-lg shadow-xl">
    </div>
</div>
</body>
</html>
