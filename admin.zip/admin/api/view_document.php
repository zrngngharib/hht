<?php
require_once '../../config/database.php';
requireLogin(); // Ensure user is logged in to view documents

$database = new Database();
$db = $database->getConnection();

$document_path = $_GET['path'] ?? ''; // Get the encrypted path from the URL

if (empty($document_path)) {
http_response_code(400);
die('Bad Request: Document path is missing.');
}

// Decrypt the path (simple base64 decode for demonstration, use stronger encryption in production)
$decoded_path = base64_decode($document_path);

// Validate the path to prevent directory traversal
$base_upload_dir = realpath(__DIR__ . '/../../uploads/documents/');
$full_file_path = realpath($base_upload_dir . '/' . basename($decoded_path)); // basename to prevent path traversal

if ($full_file_path === false || strpos($full_file_path, $base_upload_dir) !== 0) {
http_response_code(403);
die('Forbidden: Invalid document path.');
}

if (!file_exists($full_file_path)) {
http_response_code(404);
die('Not Found: Document does not exist.');
}

// Determine content type
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime_type = finfo_file($finfo, $full_file_path);
finfo_close($finfo);

if ($mime_type === false) {
$mime_type = 'application/octet-stream'; // Default if type cannot be determined
}

header('Content-Type: ' . $mime_type);
header('Content-Length: ' . filesize($full_file_path));
header('Content-Disposition: inline; filename="' . basename($full_file_path) . '"'); // inline to display in browser
readfile($full_file_path);
exit();
?>
