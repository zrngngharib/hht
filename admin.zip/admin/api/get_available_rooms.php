<?php
require_once '../../config/database.php';
requireLogin(); // Ensure user is logged in to access this API

$database = new Database();
$db = $database->getConnection();

header('Content-Type: application/json');

$check_in_date = $_GET['check_in_date'] ?? '';
$check_out_date = $_GET['check_out_date'] ?? '';

if (empty($check_in_date) || empty($check_out_date)) {
    echo json_encode([]);
    exit();
}

// Find rooms that are NOT booked within the given date range
$query = "
    SELECT r.id, r.room_number, r.price_per_night, r.capacity
    FROM rooms r
    WHERE r.status = 'available' AND r.id NOT IN (
        SELECT b.room_id
        FROM bookings b
        WHERE b.status IN ('pending', 'confirmed', 'checked-in')
        AND (
            (b.check_in_date <= ? AND b.check_out_date >= ?) OR -- Booking spans the entire period
            (b.check_in_date BETWEEN ? AND ?) OR               -- Booking starts within the period
            (b.check_out_date BETWEEN ? AND ?)                 -- Booking ends within the period
        )
    )
    ORDER BY r.room_number;
";

$stmt = $db->prepare($query);
$stmt->execute([$check_out_date, $check_in_date, $check_in_date, $check_out_date, $check_in_date, $check_out_date]);
$availableRooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($availableRooms);
?>
