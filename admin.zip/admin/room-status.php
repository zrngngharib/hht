<?php
require_once '../config/database.php';
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php?error=access_denied");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$currentMonth = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$dateObj = DateTime::createFromFormat('Y-m', $currentMonth);
if (!$dateObj) {
    $dateObj = new DateTime();
    $currentMonth = $dateObj->format('Y-m');
}

$firstDayOfMonth = $dateObj->format('Y-m-01');
$lastDayOfMonth = $dateObj->format('Y-m-t');

// Fetch all rooms
$queryRooms = "SELECT id, room_number FROM rooms ORDER BY room_number";
$stmtRooms = $db->prepare($queryRooms);
$stmtRooms->execute();
$rooms = $stmtRooms->fetchAll(PDO::FETCH_ASSOC);

// Fetch bookings for the current month
$queryBookings = "SELECT room_id, check_in_date, check_out_date, status FROM bookings 
                  WHERE (check_in_date <= ? AND check_out_date >= ?) 
                  OR (check_in_date BETWEEN ? AND ?) 
                  OR (check_out_date BETWEEN ? AND ?)";
$stmtBookings = $db->prepare($queryBookings);
$stmtBookings->execute([$lastDayOfMonth, $firstDayOfMonth, $firstDayOfMonth, $lastDayOfMonth, $firstDayOfMonth, $lastDayOfMonth]);
$bookings = $stmtBookings->fetchAll(PDO::FETCH_ASSOC);

$roomBookings = [];
foreach ($bookings as $booking) {
    $roomBookings[$booking['room_id']][] = $booking;
}

// Generate calendar days
$numDays = cal_days_in_month(CAL_GREGORIAN, $dateObj->format('m'), $dateObj->format('Y'));
$days = range(1, $numDays);

// Navigation for months
$prevMonth = $dateObj->modify('-1 month')->format('Y-m');
$dateObj->modify('+2 months'); // Go back to current month + 1
$nextMonth = $dateObj->format('Y-m');
$dateObj->modify('-1 month'); // Reset to current month
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Status - Dynasty Hotel Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fdf2f8',
                            500: '#ec4899',
                            600: '#db2777',
                            700: '#be185d',
                            900: '#831843'
                        }
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-up': 'slideUp 0.6s ease-out',
                        'pulse-slow': 'pulse 3s infinite'
                    }
                }
            }
        }
    </script>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .status-available { background-color: #dcfce7; color: #16a34a; } /* green-100, green-700 */
        .status-occupied { background-color: #fee2e2; color: #dc2626; } /* red-100, red-700 */
        .status-pending { background-color: #fef9c3; color: #a16207; } /* yellow-100, yellow-700 */
        .status-maintenance { background-color: #e0f2fe; color: #0284c7; } /* light-blue-100, light-blue-700 */
        .status-checked-in { background-color: #bfdbfe; color: #2563eb; } /* blue-200, blue-700 */
        .status-checked-out { background-color: #e9d5ff; color: #7c3aed; } /* purple-200, purple-700 */
        .status-cancelled { background-color: #fecaca; color: #b91c1c; } /* red-200, red-800 */

        .dark .status-available { background-color: #14532d; color: #86efac; } /* dark green */
        .dark .status-occupied { background-color: #7f1d1d; color: #fca5a5; } /* dark red */
        .dark .status-pending { background-color: #713f12; color: #fde047; } /* dark yellow */
        .dark .status-maintenance { background-color: #075985; color: #7dd3fc; } /* dark light-blue */
        .dark .status-checked-in { background-color: #1e3a8a; color: #93c5fd; } /* dark blue */
        .dark .status-checked-out { background-color: #4c1d95; color: #d8b4fe; } /* dark purple */
        .dark .status-cancelled { background-color: #991b1b; color: #f87171; } /* dark red */
    </style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 transition-colors duration-300" x-data="{ darkMode: false, sidebarOpen: true }" x-init="darkMode = localStorage.getItem('darkMode') === 'true'" :class="{ 'dark': darkMode }">

    <!-- Sidebar -->
    <div class="fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out" :class="{ '-translate-x-full': !sidebarOpen }">
        <div class="flex items-center justify-center h-16 bg-primary-600 text-white">
            <i class="fas fa-crown text-2xl mr-2"></i>
            <span class="text-xl font-bold">Dynasty Admin</span>
        </div>
        
        <nav class="mt-8">
            <div class="px-4 space-y-2">
                <a href="dashboard.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
                </a>
                <a href="rooms.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-bed mr-3"></i>Rooms
                </a>
                <a href="room-types.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-tags mr-3"></i>Room Types
                </a>
                <a href="bookings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-calendar-check mr-3"></i>Bookings
                </a>
                <a href="room-status.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 bg-primary-100 dark:bg-primary-900 rounded-lg">
                    <i class="fas fa-calendar-alt mr-3"></i>Room Status
                </a>
                <a href="guests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-users-line mr-3"></i>Guests
                </a>
                <a href="users.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-users mr-3"></i>Users
                </a>
                <a href="settings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-cog mr-3"></i>Settings
                </a>
                <a href="uploaded-documents.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-file-alt mr-3"></i>Uploaded Docs
                </a>
            </div>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="transition-all duration-300 ease-in-out" :class="{ 'ml-64': sidebarOpen, 'ml-0': !sidebarOpen }">
        <!-- Top Navigation -->
        <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
            <div class="flex items-center justify-between px-6 py-4">
                <div class="flex items-center space-x-4">
                    <button @click="sidebarOpen = !sidebarOpen" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Room Status</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <button @click="darkMode = !darkMode; localStorage.setItem('darkMode', darkMode)" class="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                        <i class="fas fa-moon" x-show="!darkMode"></i>
                        <i class="fas fa-sun" x-show="darkMode"></i>
                    </button>
                    
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" class="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                            <div class="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-white text-sm"></i>
                            </div>
                            <span class="font-medium"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                            <i class="fas fa-chevron-down text-sm"></i>
                        </button>
                        
                        <div x-show="open" @click.away="open = false" x-transition class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2">
                            <a href="profile.php" class="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                <i class="fas fa-user mr-2"></i>Profile
                            </a>
                            <a href="logout.php" class="block px-4 py-2 text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                <i class="fas fa-sign-out-alt mr-2"></i>Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Room Status Content -->
        <main class="p-6">
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 mb-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Room Availability for <?php echo htmlspecialchars($dateObj->format('F Y')); ?></h3>
                    <div class="flex space-x-2">
                        <a href="?month=<?php echo $prevMonth; ?>" class="bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 px-4 py-2 rounded-lg font-semibold transition-colors">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                        <a href="?month=<?php echo $nextMonth; ?>" class="bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 px-4 py-2 rounded-lg font-semibold transition-colors">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    </div>
                </div>
                
                <?php if (empty($rooms)): ?>
                    <p class="text-gray-500 dark:text-gray-400">No rooms found. Please add rooms first.</p>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white dark:bg-gray-800 rounded-lg overflow-hidden">
                            <thead class="bg-gray-100 dark:bg-gray-700">
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider sticky left-0 bg-gray-100 dark:bg-gray-700 z-10">Room</th>
                                    <?php foreach ($days as $day): ?>
                                        <th class="px-2 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider"><?php echo $day; ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                <?php foreach ($rooms as $room): ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                    <td class="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white sticky left-0 bg-white dark:bg-gray-800 z-10"><?php echo htmlspecialchars($room['room_number']); ?></td>
                                    <?php 
                                    foreach ($days as $day): 
                                        $currentDate = $dateObj->format('Y-m-') . str_pad($day, 2, '0', STR_PAD_LEFT);
                                        $statusClass = 'bg-gray-200 dark:bg-gray-700'; // Default to unknown/empty
                                        $statusText = '';

                                        if (isset($roomBookings[$room['id']])) {
                                            foreach ($roomBookings[$room['id']] as $booking) {
                                                if ($currentDate >= $booking['check_in_date'] && $currentDate <= $booking['check_out_date']) {
                                                    $statusClass = 'status-' . str_replace(' ', '-', $booking['status']);
                                                    $statusText = ucfirst($booking['status']);
                                                    break; // Found a booking for this day
                                                }
                                            }
                                        }
                                        // If no booking found, assume available
                                        if (empty($statusText)) {
                                            $statusClass = 'status-available';
                                            $statusText = 'Available';
                                        }
                                    ?>
                                        <td class="px-2 py-4 whitespace-nowrap text-center text-xs <?php echo $statusClass; ?>" title="<?php echo $statusText; ?>">
                                            <!-- You can display a small icon or initial here -->
                                            <?php 
                                                if ($statusText == 'Available') echo '<i class="fas fa-check text-green-600 dark:text-green-400"></i>';
                                                else if ($statusText == 'Occupied') echo '<i class="fas fa-times text-red-600 dark:text-red-400"></i>';
                                                else if ($statusText == 'Pending') echo '<i class="fas fa-hourglass-half text-yellow-600 dark:text-yellow-400"></i>';
                                                else if ($statusText == 'Checked-in') echo '<i class="fas fa-door-open text-blue-600 dark:text-blue-400"></i>';
                                                else if ($statusText == 'Checked-out') echo '<i class="fas fa-door-closed text-purple-600 dark:text-purple-400"></i>';
                                                else if ($statusText == 'Cancelled') echo '<i class="fas fa-ban text-red-600 dark:text-red-400"></i>';
                                                else if ($statusText == 'Maintenance') echo '<i class="fas fa-tools text-blue-600 dark:text-blue-400"></i>';
                                            ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
