<?php
require_once '../config/database.php';
requireLogin();
requireRole('admin'); // Only admin users can access this page

$database = new Database();
$db = $database->getConnection();

$message = '';
$messageType = '';

// Handle Add/Edit User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_user' || $_POST['action'] === 'edit_user') {
        $full_name = $_POST['full_name'] ?? '';
        $username = $_POST['username'] ?? '';
        $role = $_POST['role'] ?? 'staff';
        $password = $_POST['password'] ?? '';
        $user_id = $_POST['user_id'] ?? null;

        if (empty($full_name) || empty($username) || (empty($password) && $_POST['action'] === 'add_user')) {
            $message = "Please fill all required fields.";
            $messageType = 'error';
        } else {
            if ($_POST['action'] === 'add_user') {
                // Check if username already exists
                $queryCheck = "SELECT id FROM users WHERE username = ?";
                $stmtCheck = $db->prepare($queryCheck);
                $stmtCheck->execute([$username]);
                if ($stmtCheck->fetch(PDO::FETCH_ASSOC)) {
                    $message = "Username already exists. Please choose a different one.";
                    $messageType = 'error';
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $query = "INSERT INTO users (full_name, username, password, role) VALUES (?, ?, ?, ?)";
                    $stmt = $db->prepare($query);
                    if ($stmt->execute([$full_name, $username, $hashed_password, $role])) {
                        $message = "User added successfully.";
                        $messageType = 'success';
                    } else {
                        $message = "Failed to add user.";
                        $messageType = 'error';
                    }
                }
            } elseif ($_POST['action'] === 'edit_user' && $user_id) {
                $query = "UPDATE users SET full_name = ?, username = ?, role = ? WHERE id = ?";
                $params = [$full_name, $username, $role, $user_id];

                if (!empty($password)) {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $query = "UPDATE users SET full_name = ?, username = ?, password = ?, role = ? WHERE id = ?";
                    array_splice($params, 2, 0, $hashed_password); // Insert hashed password at index 2
                }

                $stmt = $db->prepare($query);
                if ($stmt->execute($params)) {
                    $message = "User updated successfully.";
                    $messageType = 'success';
                } else {
                    $message = "Failed to update user.";
                    $messageType = 'error';
                }
            }
        }
    } elseif ($_POST['action'] === 'delete_user' && isset($_POST['user_id'])) {
        $user_id = $_POST['user_id'];
        $query = "DELETE FROM users WHERE id = ?";
        $stmt = $db->prepare($query);
        if ($stmt->execute([$user_id])) {
            $message = "User deleted successfully.";
            $messageType = 'success';
        } else {
            $message = "Failed to delete user.";
            $messageType = 'error';
        }
    }
}

// Fetch all users
$queryUsers = "SELECT id, full_name, username, role FROM users ORDER BY full_name";
$stmtUsers = $db->prepare($queryUsers);
$stmtUsers->execute();
$allUsers = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Management - Dynasty Hotel Admin</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script>
    tailwind.config = {
        darkMode: 'class',
        theme: {
            extend: {
                colors: {
                    primary: {
                        50: '#fdf2f8',
                        500: '#ec4899',
                        600: '#db2777',
                        700: '#be185d',
                        900: '#831843'
                    }
                },
                animation: {
                    'fade-in': 'fadeIn 0.5s ease-in-out',
                    'slide-up': 'slideUp 0.6s ease-out',
                    'pulse-slow': 'pulse 3s infinite'
                }
            }
        }
    }
</script>
<style>
    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
    @keyframes slideUp {
        from { transform: translateY(30px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }
</style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 transition-colors duration-300" x-data="{ darkMode: false, sidebarOpen: true, showUserModal: false, currentUser: {} }" x-init="darkMode = localStorage.getItem('darkMode') === 'true'" :class="{ 'dark': darkMode }">

<!-- Sidebar -->
<div class="fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out" :class="{ '-translate-x-full': !sidebarOpen }">
    <div class="flex items-center justify-center h-16 bg-primary-600 text-white">
        <i class="fas fa-crown text-2xl mr-2"></i>
        <span class="text-xl font-bold">Dynasty Admin</span>
    </div>
    
    <nav class="mt-8">
        <div class="px-4 space-y-2">
            <a href="dashboard.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
            </a>
            <a href="rooms.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-bed mr-3"></i>Rooms
            </a>
            <a href="room-types.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-tags mr-3"></i>Room Types
            </a>
            <a href="bookings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-calendar-check mr-3"></i>Bookings
            </a>
            <a href="room-status.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-calendar-alt mr-3"></i>Room Status
            </a>
            <a href="guests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-users-line mr-3"></i>Guests
            </a>
            <a href="users.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 bg-primary-100 dark:bg-primary-900 rounded-lg">
                <i class="fas fa-users mr-3"></i>Users
            </a>
            <a href="settings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-cog mr-3"></i>Settings
            </a>
            <a href="uploaded-documents.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                <i class="fas fa-file-alt mr-3"></i>Uploaded Docs
            </a>
        </div>
    </nav>
</div>

<!-- Main Content -->
<div class="transition-all duration-300 ease-in-out" :class="{ 'ml-64': sidebarOpen, 'ml-0': !sidebarOpen }">
    <!-- Top Navigation -->
    <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div class="flex items-center justify-between px-6 py-4">
            <div class="flex items-center space-x-4">
                <button @click="sidebarOpen = !sidebarOpen" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                    <i class="fas fa-bars text-xl"></i>
                </button>
                <h1 class="text-2xl font-bold text-gray-900 dark:text-white">User Management</h1>
            </div>
            
            <div class="flex items-center space-x-4">
                <button @click="darkMode = !darkMode; localStorage.setItem('darkMode', darkMode)" class="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                    <i class="fas fa-moon" x-show="!darkMode"></i>
                    <i class="fas fa-sun" x-show="darkMode"></i>
                </button>
                
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" class="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                        <div class="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white text-sm"></i>
                        </div>
                        <span class="font-medium"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                        <i class="fas fa-chevron-down text-sm"></i>
                    </button>
                    
                    <div x-show="open" @click.away="open = false" x-transition class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2">
                        <a href="profile.php" class="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                            <i class="fas fa-user mr-2"></i>Profile
                        </a>
                        <a href="logout.php" class="block px-4 py-2 text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- User Management Content -->
    <main class="p-6">
        <?php if ($message): ?>
        <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-100 dark:bg-green-900 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-300' : 'bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-300'; ?>">
            <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i><?php echo $message; ?>
        </div>
        <?php endif; ?>

        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 mb-6">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">All Users</h3>
                <button @click="showUserModal = true; currentUser = {}" class="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
                    <i class="fas fa-plus mr-2"></i>Add New User
                </button>
            </div>
            
            <?php if (empty($allUsers)): ?>
                <p class="text-gray-500 dark:text-gray-400">No users found.</p>
            <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white dark:bg-gray-800 rounded-lg overflow-hidden">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Full Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Username</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Role</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                            <?php foreach($allUsers as $user): ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white"><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300"><?php echo htmlspecialchars($user['username']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300 capitalize"><?php echo htmlspecialchars($user['role']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <button @click="showUserModal = true; currentUser = <?php echo htmlspecialchars(json_encode($user)); ?>" class="text-primary-600 hover:text-primary-900 mr-3">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <form method="POST" class="inline-block" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                        <input type="hidden" name="action" value="delete_user">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" class="text-red-600 hover:text-red-900">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>

<!-- User Modal (Add/Edit) -->
<div x-show="showUserModal" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 scale-90" x-transition:enter-end="opacity-100 scale-100" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 scale-100" x-transition:leave-end="opacity-0 scale-90" class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60" style="display: none;">
    <div @click.away="showUserModal = false" class="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md mx-auto">
        <h3 class="text-xl font-bold text-gray-900 dark:text-white mb-4" x-text="currentUser.id ? 'Edit User' : 'Add New User'"></h3>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="action" :value="currentUser.id ? 'edit_user' : 'add_user'">
            <input type="hidden" name="user_id" x-model="currentUser.id">
            
            <div>
                <label for="full_name" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Full Name</label>
                <input type="text" id="full_name" name="full_name" x-model="currentUser.full_name" required
                       class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all duration-300">
            </div>
            <div>
                <label for="username" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Username</label>
                <input type="text" id="username" name="username" x-model="currentUser.username" required
                       class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all duration-300">
            </div>
            <div>
                <label for="password" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Password <span x-show="currentUser.id" class="text-gray-500 dark:text-gray-400 text-xs">(Leave blank to keep current)</span></label>
                <input type="password" id="password" name="password" :required="!currentUser.id"
                       class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all duration-300">
            </div>
            <div>
                <label for="role" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Role</label>
                <select id="role" name="role" x-model="currentUser.role" required
                        class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent dark:bg-gray-700 dark:text-white transition-all duration-300">
                    <option value="admin">Admin</option>
                    <option value="staff">Staff</option>
                </select>
            </div>
            
            <div class="flex justify-end space-x-3 mt-6">
                <button type="button" @click="showUserModal = false" class="bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200 px-5 py-2 rounded-lg font-semibold transition-colors">
                    Cancel
                </button>
                <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white px-5 py-2 rounded-lg font-semibold transition-colors">
                    <span x-text="currentUser.id ? 'Update User' : 'Add User'"></span>
                </button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
