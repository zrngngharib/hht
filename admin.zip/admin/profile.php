<?php
require_once '../config/database.php';
requireLogin();

// Allow both admin and staff to access profile
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php?error=access_denied");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$messageType = '';
$setPasswordPrompt = isset($_GET['set_password']) && $_GET['set_password'] === 'true';

$user_id = $_SESSION['user_id'];

// Fetch user data
$queryUser = "SELECT full_name, username, role FROM users WHERE id = ?";
$stmtUser = $db->prepare($queryUser);
$stmtUser->execute([$user_id]);
$user = $stmtUser->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // User not found, redirect to login
    header("Location: logout.php");
    exit();
}

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $full_name = $_POST['full_name'] ?? '';
    $username = $_POST['username'] ?? '';
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($full_name) || empty($username)) {
        $message = "Full name and username are required.";
        $messageType = 'error';
    } else {
        // Check if username already exists for another user
        $queryCheckUsername = "SELECT id FROM users WHERE username = ? AND id != ?";
        $stmtCheckUsername = $db->prepare($queryCheckUsername);
        $stmtCheckUsername->execute([$username, $user_id]);
        if ($stmtCheckUsername->fetch()) {
            $message = "Username already taken by another user.";
            $messageType = 'error';
        } else {
            // Handle password change
            if (!empty($new_password)) {
                if ($new_password !== $confirm_password) {
                    $message = "New password and confirm password do not match.";
                    $messageType = 'error';
                } else {
                    // Verify current password if it's not the first login for default admin
                    $queryVerifyPass = "SELECT password FROM users WHERE id = ?";
                    $stmtVerifyPass = $db->prepare($queryVerifyPass);
                    $stmtVerifyPass->execute([$user_id]);
                    $current_hashed_password = $stmtVerifyPass->fetchColumn();

                    if (empty($current_hashed_password) || password_verify($current_password, $current_hashed_password)) {
                        $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
                        $queryUpdate = "UPDATE users SET full_name = ?, username = ?, password = ? WHERE id = ?";
                        $stmtUpdate = $db->prepare($queryUpdate);
                        if ($stmtUpdate->execute([$full_name, $username, $hashed_new_password, $user_id])) {
                            $message = "Profile and password updated successfully!";
                            $messageType = 'success';
                            $_SESSION['full_name'] = $full_name; // Update session name
                            $_SESSION['username'] = $username; // Update session username
                            $setPasswordPrompt = false; // Password is set
                        } else {
                            $message = "Failed to update profile or password.";
                            $messageType = 'error';
                        }
                    } else {
                        $message = "Current password is incorrect.";
                        $messageType = 'error';
                    }
                }
            } else {
                // Update profile without changing password
                $queryUpdate = "UPDATE users SET full_name = ?, username = ? WHERE id = ?";
                $stmtUpdate = $db->prepare($queryUpdate);
                if ($stmtUpdate->execute([$full_name, $username, $user_id])) {
                    $message = "Profile updated successfully!";
                    $messageType = 'success';
                    $_SESSION['full_name'] = $full_name; // Update session name
                    $_SESSION['username'] = $username; // Update session username
                } else {
                    $message = "Failed to update profile.";
                    $messageType = 'error';
                }
            }
        }
    }
    // Re-fetch user data after update to reflect changes
    $stmtUser->execute([$user_id]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - Dynasty Hotel Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fdf2f8',
                            500: '#ec4899',
                            600: '#db2777',
                            700: '#be185d',
                            900: '#831843'
                        }
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-up': 'slideUp 0.6s ease-out',
                        'pulse-slow': 'pulse 3s infinite'
                    }
                }
            }
        }
    </script>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 transition-colors duration-300" x-data="{ darkMode: false, sidebarOpen: true }" x-init="darkMode = localStorage.getItem('darkMode') === 'true'" :class="{ 'dark': darkMode }">

    <!-- Sidebar -->
    <div class="fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out" :class="{ '-translate-x-full': !sidebarOpen }">
        <div class="flex items-center justify-center h-16 bg-primary-600 text-white">
            <i class="fas fa-crown text-2xl mr-2"></i>
            <span class="text-xl font-bold">Dynasty Admin</span>
        </div>
        
        <nav class="mt-8">
            <div class="px-4 space-y-2">
                <a href="dashboard.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
                </a>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="rooms.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-bed mr-3"></i>Rooms
                </a>
                <a href="room-types.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-tags mr-3"></i>Room Types
                </a>
                <?php endif; ?>
                <a href="bookings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-calendar-check mr-3"></i>Bookings
                </a>
                <a href="booking-requests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-inbox mr-3"></i>Booking Requests
                </a>
                <a href="room-status.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-calendar-alt mr-3"></i>Room Status
                </a>
                <a href="guests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-users-line mr-3"></i>Guests
                </a>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="users.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-users mr-3"></i>Users
                </a>
                <a href="settings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-cog mr-3"></i>Settings
                </a>
                <?php endif; ?>
                <a href="uploaded-documents.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-file-alt mr-3"></i>Uploaded Docs
                </a>
            </div>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="transition-all duration-300 ease-in-out" :class="{ 'ml-64': sidebarOpen, 'ml-0': !sidebarOpen }">
        <!-- Top Navigation -->
        <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
            <div class="flex items-center justify-between px-6 py-4">
                <div class="flex items-center space-x-4">
                    <button @click="sidebarOpen = !sidebarOpen" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-gray-900 dark:text-white">User Profile</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <button @click="darkMode = !darkMode; localStorage.setItem('darkMode', darkMode)" class="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                        <i class="fas fa-moon" x-show="!darkMode"></i>
                        <i class="fas fa-sun" x-show="darkMode"></i>
                    </button>
                    
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" class="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                            <div class="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-white text-sm"></i>
                            </div>
                            <span class="font-medium"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                            <i class="fas fa-chevron-down text-sm"></i>
                        </button>
                        
                        <div x-show="open" @click.away="open = false" x-transition class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2">
                            <a href="profile.php" class="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                <i class="fas fa-user mr-2"></i>Profile
                            </a>
                            <a href="logout.php" class="block px-4 py-2 text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                <i class="fas fa-sign-out-alt mr-2"></i>Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Profile Content -->
        <main class="p-6">
            <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-100 dark:bg-green-900 border border-green-400 dark:border-green-600 text-green-700 dark:text-green-300' : 'bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-300'; ?>">
                <span class="block sm:inline"><?php echo $message; ?></span>
            </div>
            <?php endif; ?>

            <?php if ($setPasswordPrompt): ?>
            <div class="mb-6 p-4 rounded-lg bg-yellow-100 dark:bg-yellow-900 border border-yellow-400 dark:border-yellow-600 text-yellow-700 dark:text-yellow-300">
                <i class="fas fa-exclamation-triangle mr-2"></i>Your account has no password set. Please set a new password below.
            </div>
            <?php endif; ?>

            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
                <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Update Profile</h3>
                <form action="profile.php" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input type="hidden" name="action" value="update_profile">
                    <div>
                        <label for="full_name" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Full Name:</label>
                        <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                    </div>
                    <div>
                        <label for="username" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Username:</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username'] ?? ''); ?>" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                    </div>
                    <div class="md:col-span-2">
                        <h4 class="text-md font-semibold text-gray-900 dark:text-white mt-4 mb-2">Change Password (Optional)</h4>
                    </div>
                    <div>
                        <label for="current_password" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Current Password: <?php echo $setPasswordPrompt ? '(Not required for first time setup)' : ''; ?></label>
                        <input type="password" id="current_password" name="current_password" <?php echo $setPasswordPrompt ? '' : 'required'; ?> class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                    </div>
                    <div>
                        <label for="new_password" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">New Password:</label>
                        <input type="password" id="new_password" name="new_password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                    </div>
                    <div>
                        <label for="confirm_password" class="block text-gray-700 dark:text-gray-300 text-sm font-bold mb-2">Confirm New Password:</label>
                        <input type="password" id="confirm_password" name="confirm_password" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 dark:bg-gray-700 dark:text-gray-200 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500 dark:focus:border-primary-500">
                    </div>
                    <div class="md:col-span-2 flex justify-end">
                        <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline transition-colors duration-300">
                            Update Profile
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
