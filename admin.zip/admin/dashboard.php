<?php
require_once '../config/database.php';
requireLogin();

// Allow both admin and staff to access dashboard
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'staff')) {
    header("Location: login.php?error=access_denied");
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Fetch dashboard data (example)
$totalRooms = $db->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$availableRooms = $db->query("SELECT COUNT(*) FROM rooms WHERE status = 'available'")->fetchColumn();
$totalBookings = $db->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$pendingBookings = $db->query("SELECT COUNT(*) FROM bookings WHERE status = 'pending'")->fetchColumn();
$totalGuests = $db->query("SELECT COUNT(*) FROM guests")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Dynasty Hotel Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fdf2f8',
                            500: '#ec4899',
                            600: '#db2777',
                            700: '#be185d',
                            900: '#831843'
                        }
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-up': 'slideUp 0.6s ease-out',
                        'pulse-slow': 'pulse 3s infinite'
                    }
                }
            }
        }
    </script>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from { transform: translateY(30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-gray-900 transition-colors duration-300" x-data="{ darkMode: false, sidebarOpen: true }" x-init="darkMode = localStorage.getItem('darkMode') === 'true'" :class="{ 'dark': darkMode }">

    <!-- Sidebar -->
    <div class="fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-gray-800 shadow-lg transform transition-transform duration-300 ease-in-out" :class="{ '-translate-x-full': !sidebarOpen }">
        <div class="flex items-center justify-center h-16 bg-primary-600 text-white">
            <i class="fas fa-crown text-2xl mr-2"></i>
            <span class="text-xl font-bold">Dynasty Admin</span>
        </div>
        
        <nav class="mt-8">
            <div class="px-4 space-y-2">
                <a href="dashboard.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors bg-gray-100 dark:bg-gray-700">
                    <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
                </a>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="rooms.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-bed mr-3"></i>Rooms
                </a>
                <a href="room-types.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-tags mr-3"></i>Room Types
                </a>
                <?php endif; ?>
                <a href="bookings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-calendar-check mr-3"></i>Bookings
                </a>
                <a href="booking-requests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-inbox mr-3"></i>Booking Requests
                </a>
                <a href="room-status.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-calendar-alt mr-3"></i>Room Status
                </a>
                <a href="guests.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-users-line mr-3"></i>Guests
                </a>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="users.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-users mr-3"></i>Users
                </a>
                <a href="settings.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-cog mr-3"></i>Settings
                </a>
                <?php endif; ?>
                <a href="uploaded-documents.php" class="flex items-center px-4 py-3 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                    <i class="fas fa-file-alt mr-3"></i>Uploaded Docs
                </a>
            </div>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="transition-all duration-300 ease-in-out" :class="{ 'ml-64': sidebarOpen, 'ml-0': !sidebarOpen }">
        <!-- Top Navigation -->
        <header class="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
            <div class="flex items-center justify-between px-6 py-4">
                <div class="flex items-center space-x-4">
                    <button @click="sidebarOpen = !sidebarOpen" class="text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                    <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
                </div>
                
                <div class="flex items-center space-x-4">
                    <button @click="darkMode = !darkMode; localStorage.setItem('darkMode', darkMode)" class="p-2 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors">
                        <i class="fas fa-moon" x-show="!darkMode"></i>
                        <i class="fas fa-sun" x-show="darkMode"></i>
                    </button>
                    
                    <div class="relative" x-data="{ open: false }">
                        <button @click="open = !open" class="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors">
                            <div class="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                                <i class="fas fa-user text-white text-sm"></i>
                            </div>
                            <span class="font-medium"><?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                            <i class="fas fa-chevron-down text-sm"></i>
                        </button>
                        
                        <div x-show="open" @click.away="open = false" x-transition class="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2">
                            <a href="profile.php" class="block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                <i class="fas fa-user mr-2"></i>Profile
                            </a>
                            <a href="logout.php" class="block px-4 py-2 text-red-600 dark:text-red-400 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                                <i class="fas fa-sign-out-alt mr-2"></i>Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Dashboard Content -->
        <main class="p-6">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between animate-slide-up">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-500 dark:text-gray-400">Total Rooms</h3>
                        <p class="text-3xl font-bold text-gray-900 dark:text-white"><?php echo $totalRooms; ?></p>
                    </div>
                    <i class="fas fa-bed text-primary-600 text-4xl opacity-75"></i>
                </div>
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between animate-slide-up" style="animation-delay: 0.1s;">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-500 dark:text-gray-400">Available Rooms</h3>
                        <p class="text-3xl font-bold text-gray-900 dark:text-white"><?php echo $availableRooms; ?></p>
                    </div>
                    <i class="fas fa-check-circle text-green-600 text-4xl opacity-75"></i>
                </div>
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between animate-slide-up" style="animation-delay: 0.2s;">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-500 dark:text-gray-400">Total Bookings</h3>
                        <p class="text-3xl font-bold text-gray-900 dark:text-white"><?php echo $totalBookings; ?></p>
                    </div>
                    <i class="fas fa-calendar-check text-blue-600 text-4xl opacity-75"></i>
                </div>
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 flex items-center justify-between animate-slide-up" style="animation-delay: 0.3s;">
                    <div>
                        <h3 class="text-lg font-semibold text-gray-500 dark:text-gray-400">Pending Bookings</h3>
                        <p class="text-3xl font-bold text-gray-900 dark:text-white"><?php echo $pendingBookings; ?></p>
                    </div>
                    <i class="fas fa-hourglass-half text-yellow-600 text-4xl opacity-75"></i>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 animate-fade-in">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Activities</h3>
                    <ul class="space-y-3 text-gray-700 dark:text-gray-300">
                        <li class="flex items-center"><i class="fas fa-circle text-xs text-green-500 mr-2"></i>New booking confirmed for Room 101.</li>
                        <li class="flex items-center"><i class="fas fa-circle text-xs text-blue-500 mr-2"></i>Guest John Doe checked in.</li>
                        <li class="flex items-center"><i class="fas fa-circle text-xs text-yellow-500 mr-2"></i>Room 205 status changed to maintenance.</li>
                        <li class="flex items-center"><i class="fas fa-circle text-xs text-red-500 mr-2"></i>Booking #1234 cancelled.</li>
                    </ul>
                </div>
                <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6 animate-fade-in" style="animation-delay: 0.1s;">
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Links</h3>
                    <div class="grid grid-cols-2 gap-4">
                        <a href="bookings.php?action=add" class="bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300 hover:bg-primary-200 dark:hover:bg-primary-800 p-4 rounded-lg text-center transition-colors">
                            <i class="fas fa-plus-circle text-2xl mb-2"></i>
                            <p class="font-medium">Add New Booking</p>
                        </a>
                        <a href="guests.php?action=add" class="bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-800 p-4 rounded-lg text-center transition-colors">
                            <i class="fas fa-user-plus text-2xl mb-2"></i>
                            <p class="font-medium">Add New Guest</p>
                        </a>
                        <a href="rooms.php" class="bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 hover:bg-green-200 dark:hover:bg-green-800 p-4 rounded-lg text-center transition-colors">
                            <i class="fas fa-bed text-2xl mb-2"></i>
                            <p class="font-medium">Manage Rooms</p>
                        </a>
                        <a href="room-status.php" class="bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300 hover:bg-yellow-200 dark:hover:bg-yellow-800 p-4 rounded-lg text-center transition-colors">
                            <i class="fas fa-calendar-alt text-2xl mb-2"></i>
                            <p class="font-medium">View Room Status</p>
                        </a>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
