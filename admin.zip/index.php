<?php
session_start(); // Start the session to access messages from submit_booking_request.php

$message = $_GET['message'] ?? '';
$messageType = $_GET['messageType'] ?? '';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynasty Hotel Erbil</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Custom styles for lightbox */
        .lightbox-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .lightbox-content {
            max-width: 90%;
            max-height: 90%;
            object-fit: contain;
        }
        .lightbox-close {
            position: absolute;
            top: 20px;
            right: 20px;
            color: white;
            font-size: 2rem;
            cursor: pointer;
        }
        .lightbox-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            color: white;
            font-size: 3rem;
            cursor: pointer;
            padding: 10px;
            user-select: none;
        }
        .lightbox-prev { left: 20px; }
        .lightbox-next { right: 20px; }
    </style>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#fdf2f8',
                            500: '#ec4899',
                            600: '#db2777',
                            700: '#be185d',
                            900: '#831843'
                        }
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.5s ease-in-out',
                        'slide-up': 'slideUp 0.6s ease-out',
                        'pulse-slow': 'pulse 3s infinite'
                    }
                }
            }
        }

        // Lightbox functionality
        document.addEventListener('alpine:init', () => {
            Alpine.data('lightbox', () => ({
                open: false,
                currentIndex: 0,
                images: [],
                init() {
                    this.images = Array.from(this.$el.querySelectorAll('.gallery-img')).map(img => img.src);
                },
                openLightbox(index) {
                    this.currentIndex = index;
                    this.open = true;
                },
                closeLightbox() {
                    this.open = false;
                },
                nextImage() {
                    this.currentIndex = (this.currentIndex + 1) % this.images.length;
                },
                prevImage() {
                    this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
                }
            }));
        });
    </script>
</head>
<body class="font-sans text-gray-900 bg-gray-50">

    <!-- Header -->
    <header class="bg-white shadow-md py-4">
        <div class="container mx-auto flex justify-between items-center px-4">
            <a href="#" class="text-2xl font-bold text-primary-700 flex items-center">
                <i class="fas fa-crown text-primary-600 mr-2"></i>Dynasty Hotel
            </a>
            <nav class="hidden md:block">
                <ul class="flex space-x-6">
                    <li><a href="#hero" class="text-gray-700 hover:text-primary-600 transition-colors">Home</a></li>
                    <li><a href="#gallery" class="text-gray-700 hover:text-primary-600 transition-colors">Gallery</a></li>
                    <li><a href="#booking-form" class="text-gray-700 hover:text-primary-600 transition-colors">Book Now</a></li>
                    <li><a href="#contact" class="text-gray-700 hover:text-primary-600 transition-colors">Contact</a></li>
                </ul>
            </nav>
            <div class="md:hidden">
                <button @click="mobileMenuOpen = !mobileMenuOpen" class="text-gray-700 focus:outline-none">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Mobile Menu (Alpine.js) -->
    <div x-data="{ mobileMenuOpen: false }" class="md:hidden">
        <div x-show="mobileMenuOpen" @click.away="mobileMenuOpen = false" class="fixed inset-0 bg-white z-50 flex flex-col items-center py-8 space-y-6">
            <a href="#hero" class="text-xl text-gray-700 hover:text-primary-600 transition-colors" @click="mobileMenuOpen = false">Home</a>
            <a href="#gallery" class="text-xl text-gray-700 hover:text-primary-600 transition-colors" @click="mobileMenuOpen = false">Gallery</a>
            <a href="#booking-form" class="text-xl text-gray-700 hover:text-primary-600 transition-colors" @click="mobileMenuOpen = false">Book Now</a>
            <a href="#contact" class="text-xl text-gray-700 hover:text-primary-600 transition-colors" @click="mobileMenuOpen = false">Contact</a>
        </div>
    </div>

    <!-- Hero Section -->
    <section id="hero" class="relative bg-cover bg-center h-screen flex items-center justify-center text-white" style="background-image: url('https://via.placeholder.com/1920x1080/60a5fa/ffffff?text=Hotel+Hero+Image');">
        <div class="absolute inset-0 bg-black opacity-50"></div>
        <div class="relative z-10 text-center p-4 animate-fade-in">
            <h1 class="text-4xl md:text-6xl font-extrabold leading-tight mb-4 drop-shadow-lg">Experience Luxury at Dynasty Hotel</h1>
            <p class="text-lg md:text-xl mb-8 max-w-2xl mx-auto drop-shadow-md">Your perfect getaway in the heart of Erbil. Comfort, elegance, and unforgettable memories await.</p>
            <a href="#booking-form" class="bg-primary-600 hover:bg-primary-700 text-white font-bold py-3 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105 shadow-lg">Book Your Stay</a>
        </div>
    </section>

    <!-- Gallery Section -->
    <section id="gallery" class="py-16 bg-gray-100" x-data="lightbox()">
        <div class="container mx-auto px-4">
            <h2 class="text-4xl font-bold text-center text-gray-800 mb-12 animate-slide-up">Our Photo Gallery</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php for ($i = 1; $i <= 12; $i++): ?>
                    <div class="relative group cursor-pointer overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300" @click="openLightbox(<?php echo $i - 1; ?>)">
                        <img src="https://via.placeholder.com/600x400/<?php echo sprintf('%06X', mt_rand(0, 0xFFFFFF)); ?>/ffffff?text=Hotel+Image+<?php echo $i; ?>" alt="Hotel Image <?php echo $i; ?>" class="w-full h-64 object-cover transform group-hover:scale-105 transition-transform duration-300 gallery-img">
                        <div class="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                            <i class="fas fa-search-plus text-white text-3xl"></i>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>

            <!-- Lightbox Overlay -->
            <template x-if="open">
                <div class="lightbox-overlay" @click.self="closeLightbox()">
                    <img :src="images[currentIndex]" class="lightbox-content">
                    <span class="lightbox-close" @click="closeLightbox()">&times;</span>
                    <span class="lightbox-nav lightbox-prev" @click="prevImage()"><i class="fas fa-chevron-left"></i></span>
                    <span class="lightbox-nav lightbox-next" @click="nextImage()"><i class="fas fa-chevron-right"></i></span>
                </div>
            </template>
        </div>
    </section>

    <!-- Booking Form Section -->
    <section id="booking-form" class="py-16 bg-white">
        <div class="container mx-auto px-4">
            <h2 class="text-4xl font-bold text-center text-gray-800 mb-12 animate-slide-up">Book Your Room Now</h2>
            
            <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-lg <?php echo $messageType === 'success' ? 'bg-green-100 border border-green-400 text-green-700' : 'bg-red-100 border border-red-400 text-red-700'; ?>">
                <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i><?php echo htmlspecialchars($message); ?>
            </div>
            <?php endif; ?>

            <form action="submit_booking_request.php" method="POST" class="max-w-3xl mx-auto bg-gray-50 p-8 rounded-lg shadow-lg">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <label for="full_name" class="block text-gray-700 text-sm font-bold mb-2">Full Name <span class="text-red-500">*</span></label>
                        <input type="text" id="full_name" name="full_name" required class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                    <div>
                        <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email Address <span class="text-red-500">*</span></label>
                        <input type="email" id="email" name="email" required class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                    <div>
                        <label for="phone" class="block text-gray-700 text-sm font-bold mb-2">Phone Number <span class="text-red-500">*</span></label>
                        <input type="tel" id="phone" name="phone" required class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                    <div>
                        <label for="country" class="block text-gray-700 text-sm font-bold mb-2">Country</label>
                        <input type="text" id="country" name="country" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                    <div>
                        <label for="city" class="block text-gray-700 text-sm font-bold mb-2">City</label>
                        <input type="text" id="city" name="city" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                    <div>
                        <label for="adults" class="block text-gray-700 text-sm font-bold mb-2">Adults</label>
                        <input type="number" id="adults" name="adults" value="1" min="1" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                    <div>
                        <label for="children" class="block text-gray-700 text-sm font-bold mb-2">Children</label>
                        <input type="number" id="children" name="children" value="0" min="0" class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                    <div>
                        <label for="check_in_date" class="block text-gray-700 text-sm font-bold mb-2">Check-in Date <span class="text-red-500">*</span></label>
                        <input type="date" id="check_in_date" name="check_in_date" required class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                    <div>
                        <label for="check_out_date" class="block text-gray-700 text-sm font-bold mb-2">Check-out Date <span class="text-red-500">*</span></label>
                        <input type="date" id="check_out_date" name="check_out_date" required class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-500">
                    </div>
                </div>
                <div class="flex items-center justify-center">
                    <button type="submit" class="bg-primary-600 hover:bg-primary-700 text-white font-bold py-3 px-8 rounded-full text-lg transition-all duration-300 transform hover:scale-105 shadow-lg">
                        Submit Booking Request
                    </button>
                </div>
            </form>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-16 bg-gray-800 text-white">
        <div class="container mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold mb-8">Contact Us</h2>
            <p class="text-lg mb-4">Have questions or need assistance? Reach out to us!</p>
            <div class="flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-8">
                <div class="flex items-center">
                    <i class="fas fa-map-marker-alt text-primary-500 text-2xl mr-3"></i>
                    <span>123 Hotel Street, Erbil, Kurdistan Region</span>
                </div>
                <div class="flex items-center">
                    <i class="fas fa-phone text-primary-500 text-2xl mr-3"></i>
                    <span>+964 750 123 4567</span>
                </div>
                <div class="flex items-center">
                    <i class="fas fa-envelope text-primary-500 text-2xl mr-3"></i>
                    <span>info@dynastyhotel.com</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-8">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Dynasty Hotel. All rights reserved.</p>
            <p class="mt-2">Designed and Developed by <a href="https://web.facebook.com/Zrng.N.gharib" target="_blank" class="text-primary-500 hover:underline">Zrng N Gharib</a></p>
        </div>
    </footer>

</body>
</html>
