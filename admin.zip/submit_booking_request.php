<?php
require_once 'config/database.php';

$database = new Database();
$db = $database->getConnection();

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $country = $_POST['country'] ?? '';
    $city = $_POST['city'] ?? '';
    $adults = $_POST['adults'] ?? 1;
    $children = $_POST['children'] ?? 0;
    $check_in_date = $_POST['check_in_date'] ?? '';
    $check_out_date = $_POST['check_out_date'] ?? '';

    // Basic validation
    if (empty($full_name) || empty($email) || empty($phone) || empty($check_in_date) || empty($check_out_date)) {
        $message = "Please fill all required fields: Full Name, Email, Phone, Check-in Date, Check-out Date.";
        $messageType = 'error';
    } else {
        // Validate dates
        if (strtotime($check_in_date) >= strtotime($check_out_date)) {
            $message = "Check-out date must be after check-in date.";
            $messageType = 'error';
        } else {
            $query = "INSERT INTO booking_requests (full_name, email, phone, country, city, adults, children, check_in_date, check_out_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')";
            $stmt = $db->prepare($query);
            if ($stmt->execute([$full_name, $email, $phone, $country, $city, $adults, $children, $check_in_date, $check_out_date])) {
                $message = "Your booking request has been submitted successfully! We will contact you shortly.";
                $messageType = 'success';
            } else {
                $message = "Failed to submit your booking request. Please try again.";
                $messageType = 'error';
            }
        }
    }
}

// Redirect back to index.php with message
header("Location: index.php?message=" . urlencode($message) . "&messageType=" . urlencode($messageType) . "#booking-form");
exit();
?>
