-- Migration: Alter room_types and rooms tables for capacity and price per night
-- Purpose: Move base_price and capacity from room_types to rooms table.
-- Affected Tables/Columns: room_types (DROP base_price, capacity), rooms (ADD capacity)

-- Step 1: Remove base_price and capacity from room_types
ALTER TABLE room_types
DROP COLUMN base_price,
DROP COLUMN capacity;

-- Step 2: Add capacity to rooms table
ALTER TABLE rooms
ADD COLUMN capacity INT NOT NULL DEFAULT 1;

-- Note: price_per_night already exists in rooms table.
-- You might need to manually update existing room capacities if they were previously derived from room_types.
